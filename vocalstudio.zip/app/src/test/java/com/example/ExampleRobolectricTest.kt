package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.ai.SeparationMode
import com.example.audio.ai.SourceSeparationEngine
import com.example.audio.ai.StemType
import com.example.audio.core.AudioBuffer
import com.example.audio.core.AudioPitchTempoProcessor
import com.example.audio.core.WavReader
import com.example.audio.core.WavWriter
import com.example.audio.dsp.FastFourierTransform
import com.example.audio.dsp.STFTProcessor
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import kotlin.math.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VocalStudio", appName)
    }

    @Test
    fun testFastFourierTransformIdentity() {
        val fftSize = 1024
        val fft = FastFourierTransform(fftSize)
        val real = FloatArray(fftSize) { i -> sin(2.0 * PI * 10.0 * i / fftSize).toFloat() }
        val imag = FloatArray(fftSize)

        val origReal = real.copyOf()

        fft.forward(real, imag)
        fft.inverse(real, imag)

        for (i in 0 until fftSize) {
            assertEquals(origReal[i], real[i], 1e-4f)
        }
    }

    @Test
    fun testSTFTReconstructionIdentity() {
        val stft = STFTProcessor(fftSize = 2048, hopSize = 512)
        val sampleRate = 44100
        val numSamples = sampleRate * 2
        val signal = FloatArray(numSamples) { i ->
            (0.5 * sin(2.0 * PI * 440.0 * i / sampleRate) + 0.3 * cos(2.0 * PI * 880.0 * i / sampleRate)).toFloat()
        }

        val frames = stft.forward(signal)
        val magnitudes = frames.map { it.magnitude }
        val phases = frames.map { it.phase }

        val reconstructed = stft.inverse(magnitudes, phases, numSamples)

        // Verify middle region (ignoring edge taper)
        for (i in 2048 until numSamples - 2048) {
            assertEquals(signal[i], reconstructed[i], 0.05f)
        }
    }

    @Test
    fun testWavWriterAndReader() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sampleRate = 44100
        val numSamples = sampleRate * 1
        val left = FloatArray(numSamples) { (0.4 * sin(2.0 * PI * 440.0 * it / sampleRate)).toFloat() }
        val right = FloatArray(numSamples) { (0.4 * sin(2.0 * PI * 880.0 * it / sampleRate)).toFloat() }

        val originalBuffer = AudioBuffer(left, right, sampleRate)
        val testFile = File(context.cacheDir, "unit_test_wav.wav")

        WavWriter.writeToFile(testFile, originalBuffer)
        assertTrue(testFile.exists())
        assertTrue(testFile.length() > 44)

        val reader = WavReader(testFile)
        val header = reader.readHeader()
        assertEquals(44100, header.sampleRate)
        assertEquals(2, header.channels)
        assertEquals(16, header.bitsPerSample)

        val readBuffer = reader.readAll()
        assertEquals(numSamples, readBuffer.sampleCount)
        assertTrue(readBuffer.computeRms() > 0.1f)
        assertFalse(readBuffer.hasInvalidSamples())
    }

    @Test
    fun testSourceSeparationEngine2Stem() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = SourceSeparationEngine(context)
        val sampleRate = 44100
        val numSamples = sampleRate * 2

        // Synthesize center-panned vocal + stereo wide accompaniment
        val left = FloatArray(numSamples)
        val right = FloatArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val vocal = 0.5 * sin(2.0 * PI * 1000.0 * t)
            val instL = 0.3 * sin(2.0 * PI * 4000.0 * t)
            val instR = -0.3 * sin(2.0 * PI * 4000.0 * t)
            left[i] = (vocal + instL).toFloat()
            right[i] = (vocal + instR).toFloat()
        }

        val inputBuffer = AudioBuffer(left, right, sampleRate)
        val stems = engine.processChunk(inputBuffer, SeparationMode.VOCAL_REMOVAL)

        val vocalStem = stems[StemType.VOCALS]
        val instStem = stems[StemType.INSTRUMENTAL]

        assertNotNull(vocalStem)
        assertNotNull(instStem)
        assertTrue(vocalStem!!.computeRms() > 0.01f)
        assertTrue(instStem!!.computeRms() > 0.01f)
        assertFalse(vocalStem.hasInvalidSamples())
        assertFalse(instStem.hasInvalidSamples())
    }

    @Test
    fun testPitchAndTempoShift() {
        val sampleRate = 44100
        val numSamples = sampleRate * 1
        val signal = AudioBuffer(
            FloatArray(numSamples) { (0.5 * sin(2.0 * PI * 440.0 * it / sampleRate)).toFloat() },
            FloatArray(numSamples) { (0.5 * sin(2.0 * PI * 440.0 * it / sampleRate)).toFloat() },
            sampleRate
        )

        val pitchShifted = AudioPitchTempoProcessor.processPitchShift(signal, 3.0f)
        assertEquals(numSamples, pitchShifted.sampleCount)
        assertTrue(pitchShifted.computeRms() > 0.1f)
        assertFalse(pitchShifted.hasInvalidSamples())

        val tempoShifted = AudioPitchTempoProcessor.processTempoChange(signal, 1.5f)
        assertTrue(tempoShifted.sampleCount in (numSamples / 1.6).toInt()..(numSamples / 1.4).toInt())
        assertTrue(tempoShifted.computeRms() > 0.1f)
    }
}
