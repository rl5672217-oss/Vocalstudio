package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.ai.StemType
import com.example.ui.components.AudioPlayerBar
import com.example.ui.components.WaveformView
import com.example.ui.theme.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StemMixerScreen(
    viewModel: VocalStudioViewModel,
    track: SelectedTrackInfo?,
    stems: Map<StemType, File>,
    onNavigateBack: () -> Unit
) {
    val isPlaying by viewModel.playerManager.isPlaying.collectAsState()
    val currentPosMs by viewModel.playerManager.currentPositionMs.collectAsState()
    val durationMs by viewModel.playerManager.durationMs.collectAsState()
    val activeStem by viewModel.playerManager.activeStem.collectAsState()
    val soloStem by viewModel.playerManager.soloStem.collectAsState()
    val mutedStems by viewModel.playerManager.mutedStems.collectAsState()

    val pitchShift by viewModel.pitchSemitones.collectAsState()
    val tempoSpeed by viewModel.tempoSpeed.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PolishPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = PolishOnPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = track?.title ?: "Separated Stems",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Medium,
                                letterSpacing = (-0.3).sp,
                                color = TextPrimary,
                                maxLines = 1
                            )
                            Text(
                                text = "Stem Mixer & Player",
                                fontSize = 11.sp,
                                color = PolishPrimary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            viewModel.playerManager.stop()
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("stem_mixer_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PolishBackground
                )
            )
        },
        bottomBar = {
            AudioPlayerBar(
                isPlaying = isPlaying,
                currentPosMs = currentPosMs,
                durationMs = durationMs,
                activeStem = activeStem,
                onTogglePlay = { viewModel.playerManager.togglePlayPause() },
                onSeek = { viewModel.playerManager.seekTo(it) }
            )
        },
        containerColor = PolishBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Track Overview Inset Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp)),
                color = PolishSurface,
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PolishSurfaceVariant)
                            .border(BorderStroke(1.dp, BorderSubtle), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AudioFile,
                            contentDescription = null,
                            tint = PolishPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Original Audio Track",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${track?.format ?: "WAV"} • Full Mix Reference",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }

                    IconButton(
                        onClick = { viewModel.playOriginal() },
                        modifier = Modifier.testTag("play_original_button")
                    ) {
                        val isThisPlaying = (activeStem == null && isPlaying)
                        Icon(
                            imageVector = if (isThisPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                            contentDescription = if (isThisPlaying) "Pause" else "Play",
                            tint = PolishPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AI Stems Container Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp)),
                color = PolishSurfaceVariant,
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column {
                    // Stems Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PolishSurface.copy(alpha = 0.5f))
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AI STEMS (${stems.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = TextPrimary
                        )

                        Surface(
                            color = BorderSubtle,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "OFFLINE AI INFERENCE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

                    // Individual Stems
                    stems.entries.forEachIndexed { index, (stem, file) ->
                        val isThisStemPlaying = (activeStem == stem && isPlaying)
                        val isSolo = (soloStem == stem)
                        val isMuted = mutedStems.contains(stem)

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isThisStemPlaying) PolishPrimary.copy(alpha = 0.08f) else Color.Transparent)
                                .padding(horizontal = 18.dp, vertical = 14.dp)
                                .testTag("stem_card_${stem.id}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Play / Pause Button
                                FilledIconButton(
                                    onClick = { viewModel.playStem(stem) },
                                    colors = IconButtonDefaults.filledIconButtonColors(
                                        containerColor = if (isThisStemPlaying) PolishPrimaryDark else PolishPrimary,
                                        contentColor = PolishOnPrimary
                                    ),
                                    modifier = Modifier
                                        .size(44.dp)
                                        .testTag("play_stem_${stem.id}_button")
                                ) {
                                    Icon(
                                        imageVector = if (isThisStemPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play ${stem.label}",
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stem.label,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isThisStemPlaying) PolishPrimary else TextPrimary
                                    )
                                    Text(
                                        text = when {
                                            isSolo -> "SOLO ACTIVE"
                                            isMuted -> "MUTED"
                                            isThisStemPlaying -> "Playing isolated stem..."
                                            else -> "AI Stem • Verified MP3/PCM"
                                        },
                                        fontSize = 12.sp,
                                        color = when {
                                            isSolo -> PolishPrimary
                                            isMuted -> ErrorRed
                                            isThisStemPlaying -> PolishPrimary.copy(alpha = 0.8f)
                                            else -> TextMuted
                                        }
                                    )
                                }

                                // Solo Button
                                FilterChip(
                                    selected = isSolo,
                                    onClick = { viewModel.playerManager.toggleSolo(stem, file) },
                                    label = { Text("Solo", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PolishPrimary,
                                        selectedLabelColor = PolishOnPrimary,
                                        containerColor = PolishSurface,
                                        labelColor = TextSecondary
                                    ),
                                    border = BorderStroke(1.dp, if (isSolo) PolishPrimary else BorderSubtle),
                                    modifier = Modifier.testTag("solo_stem_${stem.id}_button")
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                // Mute Button
                                FilterChip(
                                    selected = isMuted,
                                    onClick = { viewModel.playerManager.toggleMute(stem) },
                                    label = { Text("Mute", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ErrorRed,
                                        selectedLabelColor = OnError,
                                        containerColor = PolishSurface,
                                        labelColor = TextSecondary
                                    ),
                                    border = BorderStroke(1.dp, if (isMuted) ErrorRed else BorderSubtle),
                                    modifier = Modifier.testTag("mute_stem_${stem.id}_button")
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                // Individual MP3 Download Button
                                OutlinedIconButton(
                                    onClick = { viewModel.exportSingleStem(stem) },
                                    border = BorderStroke(1.dp, BorderMedium),
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .testTag("download_stem_${stem.id}_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "Download ${stem.label} MP3",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Lightweight Stem Waveform
                            WaveformView(
                                amplitudes = List(32) { i -> ((i * 7) % 10 + 2) / 12f },
                                progress = if (isThisStemPlaying && durationMs > 0) currentPosMs.toFloat() / durationMs else 0f,
                                activeColor = PolishPrimary,
                                inactiveColor = BorderSubtle,
                                height = 20.dp
                            )
                        }

                        if (index < stems.size - 1) {
                            HorizontalDivider(color = BorderSubtle, thickness = 1.dp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Real-Time Pitch & Speed Controls Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)),
                color = PolishSurface,
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "REAL-TIME DSP CONTROLS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = PolishPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Pitch Shift
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Pitch / Key Adjustment", fontSize = 13.sp, color = TextSecondary)
                        val pitchText = when {
                            pitchShift > 0 -> "+${pitchShift.toInt()} st"
                            pitchShift < 0 -> "${pitchShift.toInt()} st"
                            else -> "Original (0 st)"
                        }
                        Text(pitchText, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PolishPrimary)
                    }

                    Slider(
                        value = pitchShift,
                        onValueChange = { viewModel.setPitch(it) },
                        valueRange = -12f..12f,
                        steps = 23,
                        colors = SliderDefaults.colors(
                            thumbColor = PolishPrimary,
                            activeTrackColor = PolishPrimary,
                            inactiveTrackColor = BorderSubtle
                        ),
                        modifier = Modifier.testTag("pitch_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Tempo Speed
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Tempo / Speed Control", fontSize = 13.sp, color = TextSecondary)
                        Text("%.2fx".format(tempoSpeed), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PolishPrimary)
                    }

                    Slider(
                        value = tempoSpeed,
                        onValueChange = { viewModel.setTempo(it) },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = PolishPrimary,
                            activeTrackColor = PolishPrimary,
                            inactiveTrackColor = BorderSubtle
                        ),
                        modifier = Modifier.testTag("tempo_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                viewModel.setPitch(0f)
                                viewModel.setTempo(1.0f)
                            },
                            modifier = Modifier.testTag("reset_pitch_tempo_button")
                        ) {
                            Text("Reset Controls", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Primary Full-Width Download All Stems (Separate MP3 files, NO ZIP)
            Button(
                onClick = { viewModel.exportAllStems() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PolishPrimary,
                    contentColor = PolishOnPrimary
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("download_all_stems_primary_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DownloadForOffline,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Download All Stems (Separate MP3s)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "OFFLINE AI ENGINE V2.4 (HIGH PRECISION)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(90.dp)) // Padding for bottom player bar
        }
    }
}
