package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProcessingScreen(
    track: SelectedTrackInfo?,
    processingState: ProcessingState,
    onCancel: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "spin")
    val spinRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val progressFrac = (processingState.percentage / 100f).coerceIn(0f, 1f)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PolishPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = PolishOnPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "VocalStudio",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = (-0.3).sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBackground)
            )
        },
        containerColor = PolishBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Main "Now Processing" Card (Matches Professional Polish Theme)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .testTag("processing_card"),
                color = PolishSurface,
                border = BorderStroke(1.dp, BorderSubtle),
                shadowElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "NOW PROCESSING",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = PolishPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = track?.title ?: "Audio Track",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${track?.let { formatSec(it.durationSeconds) } ?: "00:00"} • ${track?.sampleRate ?: 44100} Hz • Stereo (32-bit PCM)",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }

                        OutlinedButton(
                            onClick = onCancel,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, BorderMedium),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = ErrorRed
                            ),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("cancel_processing_button")
                        ) {
                            Text(
                                text = "Cancel",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = ErrorRed
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Segmented / Pill Progress Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(BorderSubtle)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progressFrac)
                                .clip(RoundedCornerShape(50))
                                .background(PolishPrimary)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "${processingState.percentage}%",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Light,
                                color = PolishPrimary
                            )
                            Text(
                                text = if (processingState.totalChunks > 0)
                                    "Chunk ${processingState.currentChunk} of ${processingState.totalChunks} • Overlap-Add active"
                                else
                                    "Initializing DSP graph...",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextMuted
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = processingState.currentStage.ifEmpty { "Reconstructing Stems..." },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                            if (processingState.etaSeconds > 0) {
                                Text(
                                    text = "~${processingState.etaSeconds}s remaining",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AI Stems Live Pipeline Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp)),
                color = PolishSurfaceVariant,
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column {
                    // Stems Card Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PolishSurface.copy(alpha = 0.5f))
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AI STEMS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = TextPrimary
                        )

                        Surface(
                            color = BorderSubtle,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "LOCAL INFERENCE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

                    // Stems list live status
                    val isVocalDone = processingState.percentage > 40
                    val isInstDone = processingState.percentage > 70

                    StemProgressRow(
                        name = "Vocals",
                        statusText = if (isVocalDone) "Separated • Overlap synthesized" else "Extracting harmonic formants...",
                        isReady = isVocalDone,
                        isProcessing = !isVocalDone,
                        spinRotation = spinRotation
                    )

                    HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

                    StemProgressRow(
                        name = "Instrumental",
                        statusText = if (isInstDone) "Separated • High fidelity" else if (isVocalDone) "Synthesizing residual..." else "Queued...",
                        isReady = isInstDone,
                        isProcessing = isVocalDone && !isInstDone,
                        spinRotation = spinRotation
                    )

                    HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

                    StemProgressRow(
                        name = "Drums & Percussion",
                        statusText = if (processingState.percentage > 85) "Analyzed" else "Analyzing transient harmonics...",
                        isReady = processingState.percentage > 85,
                        isProcessing = processingState.percentage in 50..85,
                        spinRotation = spinRotation,
                        opacity = 0.6f
                    )

                    HorizontalDivider(color = BorderSubtle, thickness = 1.dp)

                    StemProgressRow(
                        name = "Bass & Melodic",
                        statusText = if (processingState.percentage >= 95) "Synthesized" else "Spectral masking queued...",
                        isReady = processingState.percentage >= 95,
                        isProcessing = processingState.percentage in 85..94,
                        spinRotation = spinRotation,
                        opacity = 0.4f
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "OFFLINE AI ENGINE V2.4 (HIGH PRECISION)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun StemProgressRow(
    name: String,
    statusText: String,
    isReady: Boolean,
    isProcessing: Boolean,
    spinRotation: Float,
    opacity: Float = 1f
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isReady) PolishPrimary.copy(alpha = 0.05f) else Color.Transparent)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isReady) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(PolishPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = PolishOnPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        } else if (isProcessing) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .border(BorderStroke(1.5.dp, PolishPrimary), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = null,
                    tint = PolishPrimary,
                    modifier = Modifier
                        .size(20.dp)
                        .rotate(spinRotation)
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .border(BorderStroke(1.dp, BorderSubtle), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.HourglassEmpty,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = name,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isReady) PolishPrimary else TextPrimary.copy(alpha = opacity)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = statusText,
                fontSize = 12.sp,
                color = if (isReady) TextSecondary else TextMuted
            )
        }
    }
}

private fun formatSec(sec: Double): String {
    val totalSec = sec.toInt()
    val min = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(min, s)
}

