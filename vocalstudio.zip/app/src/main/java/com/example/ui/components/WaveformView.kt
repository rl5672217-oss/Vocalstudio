package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple

@Composable
fun WaveformView(
    amplitudes: List<Float>,
    progress: Float = 0f, // 0.0 to 1.0
    activeColor: Color = NeonCyan,
    inactiveColor: Color = Color(0xFF2A3040),
    height: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        if (amplitudes.isEmpty()) return@Canvas

        val canvasWidth = size.width
        val canvasHeight = size.height
        val barCount = amplitudes.size
        val barSpacing = 3.dp.toPx()
        val totalSpacing = barSpacing * (barCount - 1)
        val barWidth = ((canvasWidth - totalSpacing) / barCount).coerceAtLeast(2.dp.toPx())

        val currentProgressX = canvasWidth * progress.coerceIn(0f, 1f)

        for (i in 0 until barCount) {
            val barHeight = (amplitudes[i] * canvasHeight * 0.9f).coerceAtLeast(4.dp.toPx())
            val x = i * (barWidth + barSpacing)
            val y = (canvasHeight - barHeight) / 2f

            val isPlayed = (x + barWidth / 2) <= currentProgressX
            val color = if (isPlayed) activeColor else inactiveColor

            drawRoundRect(
                color = color,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}
