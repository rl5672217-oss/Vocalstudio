package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.components.SplashScreen
import com.example.ui.theme.VocalStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VocalStudioTheme {
                val viewModel: VocalStudioViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()
                val selectedTrack by viewModel.selectedTrack.collectAsState()
                val selectedMode by viewModel.selectedMode.collectAsState()
                val processingState by viewModel.processingState.collectAsState()
                val generatedStems by viewModel.generatedStems.collectAsState()
                val toastMessage by viewModel.toastMessage.collectAsState()

                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(toastMessage) {
                    toastMessage?.let { msg ->
                        snackbarHostState.showSnackbar(msg)
                        viewModel.clearToast()
                    }
                }

                // Handle hardware/gesture back navigation
                BackHandler(enabled = currentScreen != AppScreen.Main && currentScreen != AppScreen.Splash) {
                    when (currentScreen) {
                        is AppScreen.Processing -> viewModel.cancelProcessing()
                        is AppScreen.Results,
                        is AppScreen.History,
                        is AppScreen.Diagnostic -> viewModel.navigateTo(AppScreen.Main)
                        else -> {}
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { _ ->
                    when (currentScreen) {
                        is AppScreen.Splash -> {
                            SplashScreen(
                                onSplashFinished = {
                                    viewModel.navigateTo(AppScreen.Main)
                                }
                            )
                        }
                        is AppScreen.Main -> {
                            StudioMainScreen(
                                viewModel = viewModel,
                                selectedTrack = selectedTrack,
                                selectedMode = selectedMode,
                                onStartSeparation = { viewModel.startSeparation() },
                                onNavigateToHistory = { viewModel.navigateTo(AppScreen.History) },
                                onNavigateToDiagnostic = { viewModel.navigateTo(AppScreen.Diagnostic) }
                            )
                        }
                        is AppScreen.Processing -> {
                            ProcessingScreen(
                                track = selectedTrack,
                                processingState = processingState,
                                onCancel = { viewModel.cancelProcessing() }
                            )
                        }
                        is AppScreen.Results -> {
                            StemMixerScreen(
                                viewModel = viewModel,
                                track = selectedTrack,
                                stems = generatedStems,
                                onNavigateBack = { viewModel.navigateTo(AppScreen.Main) }
                            )
                        }
                        is AppScreen.History -> {
                            HistoryScreen(
                                viewModel = viewModel,
                                onNavigateBack = { viewModel.navigateTo(AppScreen.Main) }
                            )
                        }
                        is AppScreen.Diagnostic -> {
                            DiagnosticScreen(
                                viewModel = viewModel,
                                onNavigateBack = { viewModel.navigateTo(AppScreen.Main) }
                            )
                        }
                    }
                }
            }
        }
    }
}
