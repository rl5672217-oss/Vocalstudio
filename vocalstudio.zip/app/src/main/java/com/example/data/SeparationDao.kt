package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SeparationDao {
    @Query("SELECT * FROM separation_records ORDER BY createdAt DESC")
    fun getAllRecords(): Flow<List<SeparationRecord>>

    @Query("SELECT * FROM separation_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: Long): SeparationRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: SeparationRecord): Long

    @Delete
    suspend fun deleteRecord(record: SeparationRecord)

    @Query("DELETE FROM separation_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)
}
