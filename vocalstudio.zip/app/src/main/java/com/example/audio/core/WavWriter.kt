package com.example.audio.core

import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Standard RIFF/WAVE 16-bit signed PCM file writer.
 * Supports streaming append for memory-efficient processing of long audio files.
 */
class WavWriter(
    val outputFile: File,
    val sampleRate: Int = 44100,
    val channels: Int = 2
) : AutoCloseable {

    private val bytesPerSample = 2 // 16-bit PCM
    private val blockAlign = channels * bytesPerSample
    private val byteRate = sampleRate * blockAlign
    private val outputStream = FileOutputStream(outputFile)
    private var totalBytesWritten = 0L

    init {
        // Write placeholder 44-byte header
        val header = ByteArray(44)
        outputStream.write(header)
    }

    /**
     * Appends an AudioBuffer (floating point PCM) to the WAV file.
     */
    fun append(buffer: AudioBuffer) {
        val pcmBytes = buffer.toPcm16LittleEndian()
        outputStream.write(pcmBytes)
        totalBytesWritten += pcmBytes.size
    }

    /**
     * Appends raw 16-bit PCM bytes to the WAV file.
     */
    fun appendBytes(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size) {
        outputStream.write(bytes, offset, length)
        totalBytesWritten += length
    }

    /**
     * Finalizes the WAV header with actual data chunk sizes and closes the stream.
     */
    override fun close() {
        outputStream.flush()
        outputStream.close()

        // Seek back to write actual header
        RandomAccessFile(outputFile, "rw").use { raf ->
            raf.seek(0)
            val headerBuffer = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)

            val totalDataLen = totalBytesWritten
            val totalFileLen = totalDataLen + 36

            // "RIFF"
            headerBuffer.put('R'.code.toByte())
            headerBuffer.put('I'.code.toByte())
            headerBuffer.put('F'.code.toByte())
            headerBuffer.put('F'.code.toByte())

            // File size minus 8
            headerBuffer.putInt((totalFileLen and 0xFFFFFFFFL).toInt())

            // "WAVE"
            headerBuffer.put('W'.code.toByte())
            headerBuffer.put('A'.code.toByte())
            headerBuffer.put('V'.code.toByte())
            headerBuffer.put('E'.code.toByte())

            // "fmt "
            headerBuffer.put('f'.code.toByte())
            headerBuffer.put('m'.code.toByte())
            headerBuffer.put('t'.code.toByte())
            headerBuffer.put(' '.code.toByte())

            // SubChunk1Size (16 for PCM)
            headerBuffer.putInt(16)

            // AudioFormat (1 for PCM)
            headerBuffer.putShort(1.toShort())

            // NumChannels
            headerBuffer.putShort(channels.toShort())

            // SampleRate
            headerBuffer.putInt(sampleRate)

            // ByteRate
            headerBuffer.putInt(byteRate)

            // BlockAlign
            headerBuffer.putShort(blockAlign.toShort())

            // BitsPerSample
            headerBuffer.putShort(16.toShort())

            // "data"
            headerBuffer.put('d'.code.toByte())
            headerBuffer.put('a'.code.toByte())
            headerBuffer.put('t'.code.toByte())
            headerBuffer.put('a'.code.toByte())

            // SubChunk2Size
            headerBuffer.putInt((totalDataLen and 0xFFFFFFFFL).toInt())

            raf.write(headerBuffer.array())
        }
    }

    companion object {
        /**
         * Writes a complete AudioBuffer directly to a WAV file.
         */
        fun writeToFile(file: File, buffer: AudioBuffer) {
            WavWriter(file, buffer.sampleRate, 2).use { writer ->
                writer.append(buffer)
            }
        }
    }
}
