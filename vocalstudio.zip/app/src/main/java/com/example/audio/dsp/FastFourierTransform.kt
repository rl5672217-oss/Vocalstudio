package com.example.audio.dsp

import kotlin.math.*

/**
 * High-performance Fast Fourier Transform (FFT) and Inverse Fast Fourier Transform (IFFT)
 * implemented with Cooley-Tukey Radix-2 algorithm and lookup tables.
 */
class FastFourierTransform(val fftSize: Int) {
    init {
        require(fftSize > 0 && (fftSize and (fftSize - 1)) == 0) {
            "FFT size must be a power of 2, got: $fftSize"
        }
    }

    private val log2N = (ln(fftSize.toDouble()) / ln(2.0)).roundToInt()
    private val bitRev = IntArray(fftSize)
    private val cosTable = FloatArray(fftSize / 2)
    private val sinTable = FloatArray(fftSize / 2)

    init {
        // Precompute bit-reversal table
        for (i in 0 until fftSize) {
            var rev = 0
            var temp = i
            for (j in 0 until log2N) {
                rev = (rev shl 1) or (temp and 1)
                temp = temp shr 1
            }
            bitRev[i] = rev
        }

        // Precompute twiddle factor trig tables
        for (i in 0 until fftSize / 2) {
            val angle = -2.0 * Math.PI * i / fftSize
            cosTable[i] = cos(angle).toFloat()
            sinTable[i] = sin(angle).toFloat()
        }
    }

    /**
     * In-place forward FFT.
     * @param real Real components (size = fftSize)
     * @param imag Imaginary components (size = fftSize)
     */
    fun forward(real: FloatArray, imag: FloatArray) {
        // Bit-reversal permutation
        for (i in 0 until fftSize) {
            val j = bitRev[i]
            if (i < j) {
                val tempR = real[i]
                real[i] = real[j]
                real[j] = tempR

                val tempI = imag[i]
                imag[i] = imag[j]
                imag[j] = tempI
            }
        }

        // Cooley-Tukey Radix-2 decimation-in-time
        var halfSize = 1
        while (halfSize < fftSize) {
            val step = halfSize shl 1
            val tableStep = fftSize / step

            for (m in 0 until halfSize) {
                val wr = cosTable[m * tableStep]
                val wi = sinTable[m * tableStep]

                var i = m
                while (i < fftSize) {
                    val j = i + halfSize
                    val tr = wr * real[j] - wi * imag[j]
                    val ti = wr * imag[j] + wi * real[j]

                    real[j] = real[i] - tr
                    imag[j] = imag[i] - ti
                    real[i] += tr
                    imag[i] += ti

                    i += step
                }
            }
            halfSize = step
        }
    }

    /**
     * In-place inverse FFT.
     * @param real Real components (size = fftSize)
     * @param imag Imaginary components (size = fftSize)
     */
    fun inverse(real: FloatArray, imag: FloatArray) {
        // Complex conjugate: negate imaginary
        for (i in 0 until fftSize) {
            imag[i] = -imag[i]
        }

        forward(real, imag)

        // Complex conjugate and scale by 1/N
        val invN = 1f / fftSize
        for (i in 0 until fftSize) {
            real[i] = real[i] * invN
            imag[i] = -imag[i] * invN
        }
    }
}
