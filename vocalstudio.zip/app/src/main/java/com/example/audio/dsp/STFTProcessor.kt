package com.example.audio.dsp

import kotlin.math.*

/**
 * Short-Time Fourier Transform (STFT) and Inverse STFT (ISTFT) processor.
 * Preserves full complex phase information and uses Hann window with normalized overlap-add.
 */
class STFTProcessor(
    val fftSize: Int = 2048,
    val hopSize: Int = 512
) {
    private val fft = FastFourierTransform(fftSize)
    val numFreqBins = fftSize / 2 + 1
    val window: FloatArray = FloatArray(fftSize)

    init {
        // Periodic Hann window
        for (i in 0 until fftSize) {
            window[i] = (0.5 * (1.0 - cos(2.0 * Math.PI * i / fftSize))).toFloat()
        }
    }

    /**
     * Spectrogram frame holding magnitude, phase, real, and imaginary parts.
     */
    data class ComplexFrame(
        val real: FloatArray,
        val imag: FloatArray,
        val magnitude: FloatArray,
        val phase: FloatArray
    )

    /**
     * Performs forward STFT on a single channel audio signal.
     * Returns a list of ComplexFrames.
     */
    fun forward(signal: FloatArray): List<ComplexFrame> {
        val numFrames = if (signal.size < fftSize) 1 else ((signal.size - fftSize) / hopSize) + 1
        val frames = ArrayList<ComplexFrame>(numFrames)

        val realBuf = FloatArray(fftSize)
        val imagBuf = FloatArray(fftSize)

        for (f in 0 until numFrames) {
            val start = f * hopSize
            // Window signal segment
            for (i in 0 until fftSize) {
                val sigIdx = start + i
                val sample = if (sigIdx < signal.size) signal[sigIdx] else 0f
                realBuf[i] = sample * window[i]
                imagBuf[i] = 0f
            }

            fft.forward(realBuf, imagBuf)

            val mag = FloatArray(numFreqBins)
            val phase = FloatArray(numFreqBins)
            val realOut = FloatArray(numFreqBins)
            val imagOut = FloatArray(numFreqBins)

            for (k in 0 until numFreqBins) {
                val r = realBuf[k]
                val im = imagBuf[k]
                realOut[k] = r
                imagOut[k] = im
                mag[k] = sqrt(r * r + im * im)
                phase[k] = atan2(im, r)
            }

            frames.add(ComplexFrame(realOut, imagOut, mag, phase))
        }

        return frames
    }

    /**
     * Reconstructs time-domain audio signal from magnitude spectrogram and original phase frames.
     * Uses synthesis windowing and normalized overlap-add.
     */
    fun inverse(
        magnitudes: List<FloatArray>,
        phases: List<FloatArray>,
        outputLength: Int
    ): FloatArray {
        val numFrames = min(magnitudes.size, phases.size)
        val reconstructed = FloatArray(outputLength)
        val windowWeightSum = FloatArray(outputLength)

        val realBuf = FloatArray(fftSize)
        val imagBuf = FloatArray(fftSize)

        for (f in 0 until numFrames) {
            val mag = magnitudes[f]
            val phase = phases[f]

            // Reconstruct Hermitian symmetric complex spectrum
            for (k in 0 until numFreqBins) {
                val m = mag[k]
                val p = phase[k]
                realBuf[k] = m * cos(p)
                imagBuf[k] = m * sin(p)
            }

            // Fill upper negative frequencies (Hermitian symmetry for real output)
            for (k in numFreqBins until fftSize) {
                val mirror = fftSize - k
                realBuf[k] = realBuf[mirror]
                imagBuf[k] = -imagBuf[mirror]
            }

            fft.inverse(realBuf, imagBuf)

            val start = f * hopSize
            for (i in 0 until fftSize) {
                val targetIdx = start + i
                if (targetIdx < outputLength) {
                    val w = window[i]
                    reconstructed[targetIdx] += realBuf[i] * w
                    windowWeightSum[targetIdx] += w * w
                }
            }
        }

        // Overlap-add normalization to prevent amplitude modulation and distortion
        for (i in 0 until outputLength) {
            val weight = windowWeightSum[i]
            if (weight > 1e-6f) {
                reconstructed[i] /= weight
            }
        }

        return reconstructed
    }
}
