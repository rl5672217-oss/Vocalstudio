package com.example.audio.core

import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/**
 * Streaming parser for standard WAV/RIFF files.
 */
class WavReader(val file: File) {

    data class WavHeader(
        val channels: Int,
        val sampleRate: Int,
        val bitsPerSample: Int,
        val audioFormat: Int, // 1 for PCM, 3 for IEEE Float
        val dataOffset: Long,
        val dataSize: Long
    ) {
        val durationSeconds: Double
            get() = if (sampleRate > 0 && channels > 0 && bitsPerSample > 0) {
                dataSize.toDouble() / (sampleRate * channels * (bitsPerSample / 8))
            } else 0.0
    }

    fun readHeader(): WavHeader {
        val fileLen = file.length()
        if (fileLen < 44) {
            throw IllegalArgumentException("Invalid WAV file: File too small ($fileLen bytes)")
        }

        FileInputStream(file).use { stream ->
            val buf = ByteArray(min(4096, fileLen.toInt()))
            val bytesRead = stream.read(buf)
            if (bytesRead < 44) {
                throw IllegalArgumentException("Invalid WAV file: Header too small")
            }

            val byteBuf = ByteBuffer.wrap(buf, 0, bytesRead).order(ByteOrder.LITTLE_ENDIAN)

            val riff = String(buf, 0, 4)
            if (riff != "RIFF") {
                throw IllegalArgumentException("Not a valid RIFF file: $riff")
            }

            val wave = String(buf, 8, 4)
            if (wave != "WAVE") {
                throw IllegalArgumentException("Not a valid WAVE file: $wave")
            }

            var audioFormat = 1
            var channels = 2
            var sampleRate = 44100
            var bitsPerSample = 16
            var dataOffset = 44L
            var dataSize = fileLen - 44

            var pos = 12
            while (pos + 8 <= bytesRead) {
                val chunkId = String(buf, pos, 4)
                val chunkSize = (byteBuf.getInt(pos + 4).toLong() and 0xFFFFFFFFL).coerceAtLeast(0L)

                if (chunkId == "fmt ") {
                    if (pos + 8 + 16 <= bytesRead) {
                        audioFormat = byteBuf.getShort(pos + 8).toInt()
                        channels = byteBuf.getShort(pos + 10).toInt().coerceAtLeast(1)
                        sampleRate = byteBuf.getInt(pos + 12).coerceAtLeast(8000)
                        bitsPerSample = byteBuf.getShort(pos + 22).toInt().coerceAtLeast(8)
                    }
                } else if (chunkId == "data") {
                    dataOffset = (pos + 8).toLong()
                    dataSize = min(chunkSize, fileLen - dataOffset)
                    break
                }

                pos += (8 + chunkSize.toInt())
            }

            return WavHeader(
                channels = channels,
                sampleRate = sampleRate,
                bitsPerSample = bitsPerSample,
                audioFormat = audioFormat,
                dataOffset = dataOffset,
                dataSize = max(0L, dataSize)
            )
        }
    }

    /**
     * Reads entire WAV audio into an AudioBuffer (convenience for small files/tests).
     */
    fun readAll(): AudioBuffer {
        val header = readHeader()
        val bytesPerSample = (header.bitsPerSample / 8).coerceAtLeast(1)
        val frameSize = header.channels * bytesPerSample
        val totalSamples = (header.dataSize / frameSize).toInt().coerceIn(0, 10_000_000)

        val left = FloatArray(totalSamples)
        val right = FloatArray(totalSamples)

        FileInputStream(file).use { stream ->
            stream.skip(header.dataOffset)
            val pcmBytes = ByteArray(4096)
            val byteBuf = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)

            var sampleIdx = 0
            var bytesRead: Int
            while (stream.read(pcmBytes).also { bytesRead = it } != -1 && sampleIdx < totalSamples) {
                byteBuf.position(0)
                byteBuf.limit(bytesRead)

                val samplesInBuf = bytesRead / frameSize
                for (s in 0 until samplesInBuf) {
                    if (sampleIdx >= totalSamples) break

                    if (header.bitsPerSample == 16) {
                        val lVal = byteBuf.short / 32768.0f
                        val rVal = if (header.channels >= 2) byteBuf.short / 32768.0f else lVal
                        left[sampleIdx] = lVal
                        right[sampleIdx] = rVal
                    } else if (header.bitsPerSample == 32 && header.audioFormat == 3) {
                        val lVal = byteBuf.float
                        val rVal = if (header.channels >= 2) byteBuf.float else lVal
                        left[sampleIdx] = lVal
                        right[sampleIdx] = rVal
                    } else {
                        val lVal = byteBuf.short / 32768.0f
                        val rVal = if (header.channels >= 2) byteBuf.short / 32768.0f else lVal
                        left[sampleIdx] = lVal
                        right[sampleIdx] = rVal
                    }
                    sampleIdx++
                }
            }
        }

        return AudioBuffer(left, right, header.sampleRate)
    }
}
