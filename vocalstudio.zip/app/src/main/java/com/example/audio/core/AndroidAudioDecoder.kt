package com.example.audio.core

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/**
 * Robust audio decoder supporting MP3, WAV, AAC, and M4A.
 * Decodes into normalized floating-point PCM audio in streaming chunks.
 */
class AndroidAudioDecoder(private val context: Context) {

    data class DecodedInfo(
        val sampleRate: Int,
        val channelCount: Int,
        val durationMs: Long,
        val mimeType: String
    )

    /**
     * Extracts audio stream metadata from a file or content URI.
     */
    fun extractInfo(fileOrUri: Any): DecodedInfo {
        val extractor = MediaExtractor()
        try {
            when (fileOrUri) {
                is File -> extractor.setDataSource(fileOrUri.absolutePath)
                is Uri -> extractor.setDataSource(context, fileOrUri, null)
                is String -> extractor.setDataSource(fileOrUri)
                else -> throw IllegalArgumentException("Unsupported source type: $fileOrUri")
            }

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
                    val channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                    val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
                    return DecodedInfo(
                        sampleRate = sampleRate,
                        channelCount = channels,
                        durationMs = durationUs / 1000,
                        mimeType = mime
                    )
                }
            }
            throw IllegalStateException("No audio track found in file.")
        } finally {
            extractor.release()
        }
    }

    /**
     * Decodes the entire audio source to a raw stereo PCM FloatArray file or memory buffer.
     * For long files, streams decoded PCM samples to [onChunkDecoded] callback.
     */
    fun decodeStreaming(
        fileOrUri: Any,
        targetSampleRate: Int = 44100,
        chunkSizeSamples: Int = 44100 * 10, // 10-second chunks by default
        onChunkDecoded: (AudioBuffer, isLastChunk: Boolean) -> Unit
    ) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null

        try {
            when (fileOrUri) {
                is File -> extractor.setDataSource(fileOrUri.absolutePath)
                is Uri -> extractor.setDataSource(context, fileOrUri, null)
                is String -> extractor.setDataSource(fileOrUri)
                else -> throw IllegalArgumentException("Unsupported source type: $fileOrUri")
            }

            var audioTrackIndex = -1
            var trackFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    trackFormat = format
                    break
                }
            }

            if (audioTrackIndex < 0 || trackFormat == null) {
                throw IllegalStateException("No valid audio track found in input file.")
            }

            extractor.selectTrack(audioTrackIndex)
            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(trackFormat, null, null, 0)
            codec.start()

            val srcSampleRate = if (trackFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) trackFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var srcChannels = if (trackFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) trackFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2

            val bufferInfo = MediaCodec.BufferInfo()
            var isInputEOS = false
            var isOutputEOS = false

            var leftAccum = FloatArray(chunkSizeSamples)
            var rightAccum = FloatArray(chunkSizeSamples)
            var accumCount = 0

            val timeoutUs = 5000L

            while (!isOutputEOS) {
                if (!isInputEOS) {
                    val inputBufIndex = codec.dequeueInputBuffer(timeoutUs)
                    if (inputBufIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputBufIndex) ?: continue
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputBufIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isInputEOS = true
                        } else {
                            val presentationTimeUs = extractor.sampleTime
                            codec.queueInputBuffer(inputBufIndex, 0, sampleSize, presentationTimeUs, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputBufIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outputBufIndex >= 0) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isOutputEOS = true
                    }

                    val outputBuffer = codec.getOutputBuffer(outputBufIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val pcmShorts = outputBuffer.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val numShorts = pcmShorts.remaining()
                        val numSamples = numShorts / srcChannels

                        for (s in 0 until numSamples) {
                            val lVal = pcmShorts.get() / 32768.0f
                            val rVal = if (srcChannels >= 2) pcmShorts.get() / 32768.0f else lVal

                            if (accumCount >= chunkSizeSamples) {
                                onChunkDecoded(AudioBuffer(leftAccum.copyOf(accumCount), rightAccum.copyOf(accumCount), srcSampleRate), false)
                                accumCount = 0
                            }

                            leftAccum[accumCount] = lVal
                            rightAccum[accumCount] = rVal
                            accumCount++
                        }
                    }

                    codec.releaseOutputBuffer(outputBufIndex, false)
                } else if (outputBufIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = codec.outputFormat
                    if (newFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcChannels = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }

            // Flush remaining samples in final chunk
            if (accumCount > 0) {
                onChunkDecoded(AudioBuffer(leftAccum.copyOf(accumCount), rightAccum.copyOf(accumCount), srcSampleRate), true)
            } else {
                // If audio was already empty or exactly aligned, send empty final chunk
                onChunkDecoded(AudioBuffer.silence(0, srcSampleRate), true)
            }

        } catch (e: Exception) {
            Log.e("AndroidAudioDecoder", "Decoding error: ${e.message}", e)
            throw e
        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (ignored: Exception) {}
            try {
                extractor.release()
            } catch (ignored: Exception) {}
        }
    }
}
