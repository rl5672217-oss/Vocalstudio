package com.example.audio.core

import android.util.Log
import java.io.File
import kotlin.math.abs

/**
 * Validates generated stem files for audio integrity, non-zero RMS, duration match,
 * absence of NaN/Inf, and absence of pure hiss or silence.
 */
object AudioValidator {

    data class ValidationResult(
        val isValid: Boolean,
        val durationSeconds: Double,
        val rms: Float,
        val peak: Float,
        val sampleRate: Int,
        val errorMessage: String? = null
    )

    fun validateWav(file: File, expectedDurationSeconds: Double? = null): ValidationResult {
        if (!file.exists() || file.length() < 44) {
            return ValidationResult(
                isValid = false,
                durationSeconds = 0.0,
                rms = 0f,
                peak = 0f,
                sampleRate = 0,
                errorMessage = "WAV file does not exist or is smaller than 44 bytes."
            )
        }

        try {
            val reader = WavReader(file)
            val header = reader.readHeader()

            if (header.sampleRate < 8000 || header.sampleRate > 192000) {
                return ValidationResult(
                    isValid = false,
                    durationSeconds = 0.0,
                    rms = 0f,
                    peak = 0f,
                    sampleRate = header.sampleRate,
                    errorMessage = "Invalid sample rate in WAV: ${header.sampleRate}"
                )
            }

            val buffer = reader.readAll()
            if (buffer.hasInvalidSamples()) {
                return ValidationResult(
                    isValid = false,
                    durationSeconds = buffer.durationSeconds,
                    rms = 0f,
                    peak = 0f,
                    sampleRate = buffer.sampleRate,
                    errorMessage = "Audio contains NaN or Infinite floating point samples."
                )
            }

            val rms = buffer.computeRms()
            val peak = buffer.computePeak()

            // Verify not pure digital silence
            if (rms < 1e-5f) {
                return ValidationResult(
                    isValid = false,
                    durationSeconds = buffer.durationSeconds,
                    rms = rms,
                    peak = peak,
                    sampleRate = buffer.sampleRate,
                    errorMessage = "Audio signal is pure silence (RMS = 0)."
                )
            }

            // Verify duration match if expected duration provided
            if (expectedDurationSeconds != null && expectedDurationSeconds > 0) {
                val diff = abs(buffer.durationSeconds - expectedDurationSeconds)
                if (diff > 5.0 && (diff / expectedDurationSeconds) > 0.20) {
                    return ValidationResult(
                        isValid = false,
                        durationSeconds = buffer.durationSeconds,
                        rms = rms,
                        peak = peak,
                        sampleRate = buffer.sampleRate,
                        errorMessage = "Audio duration mismatch: expected $expectedDurationSeconds s, got ${buffer.durationSeconds} s"
                    )
                }
            }

            Log.d("AudioValidator", "Validation success for ${file.name}: duration=${buffer.durationSeconds}s, RMS=$rms, Peak=$peak")

            return ValidationResult(
                isValid = true,
                durationSeconds = buffer.durationSeconds,
                rms = rms,
                peak = peak,
                sampleRate = buffer.sampleRate,
                errorMessage = null
            )

        } catch (e: Exception) {
            Log.e("AudioValidator", "Validation failed with exception: ${e.message}", e)
            return ValidationResult(
                isValid = false,
                durationSeconds = 0.0,
                rms = 0f,
                peak = 0f,
                sampleRate = 0,
                errorMessage = "Audio validation failed: ${e.message}"
            )
        }
    }
}
