package com.example.audio.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.audio.ai.StemType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import kotlin.math.pow

/**
 * Enhanced audio playback manager with support for:
 * - Individual stem playback with auto-pause
 * - Solo mode (isolates selected stem)
 * - Mute mode (mutes selected stem)
 * - Multi-stem synchronized mix preview
 * - Real-time pitch (-12..+12 semitones) and tempo (0.5x..2.0x) control.
 */
class StemPlayerManager(private val context: Context) {

    private var exoPlayer: ExoPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _activeStem = MutableStateFlow<StemType?>(null)
    val activeStem: StateFlow<StemType?> = _activeStem.asStateFlow()

    // Solo and Mute states per stem
    private val _soloStem = MutableStateFlow<StemType?>(null)
    val soloStem: StateFlow<StemType?> = _soloStem.asStateFlow()

    private val _mutedStems = MutableStateFlow<Set<StemType>>(emptySet())
    val mutedStems: StateFlow<Set<StemType>> = _mutedStems.asStateFlow()

    private var currentFile: File? = null
    private var semitones: Float = 0f
    private var tempo: Float = 1.0f

    private var progressJob: Job? = null

    init {
        initPlayer()
    }

    private fun initPlayer() {
        exoPlayer = ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) {
                    _isPlaying.value = playing
                    if (playing) {
                        startProgressTracker()
                    } else {
                        progressJob?.cancel()
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        _durationMs.value = exoPlayer?.duration?.coerceAtLeast(0L) ?: 0L
                    } else if (playbackState == Player.STATE_ENDED) {
                        _isPlaying.value = false
                        _currentPositionMs.value = _durationMs.value
                    }
                }
            })
        }
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && exoPlayer?.isPlaying == true) {
                _currentPositionMs.value = exoPlayer?.currentPosition?.coerceAtLeast(0L) ?: 0L
                delay(100)
            }
        }
    }

    /**
     * Loads and plays a stem file or original audio.
     */
    fun playStem(file: File, stem: StemType?) {
        if (!file.exists()) return

        currentFile = file
        _activeStem.value = stem

        exoPlayer?.let { player ->
            player.stop()
            player.clearMediaItems()
            val mediaItem = MediaItem.fromUri(Uri.fromFile(file))
            player.setMediaItem(mediaItem)
            updatePlaybackParams()
            updateVolume()
            player.prepare()
            player.play()
        }
    }

    /**
     * Toggles solo on a specific stem.
     * When soloed, only this stem will play.
     */
    fun toggleSolo(stem: StemType, file: File) {
        if (_soloStem.value == stem) {
            _soloStem.value = null
        } else {
            _soloStem.value = stem
            _mutedStems.value = _mutedStems.value - stem
            playStem(file, stem)
        }
        updateVolume()
    }

    /**
     * Toggles mute state for a specific stem.
     */
    fun toggleMute(stem: StemType) {
        val currentMuted = _mutedStems.value
        if (currentMuted.contains(stem)) {
            _mutedStems.value = currentMuted - stem
        } else {
            _mutedStems.value = currentMuted + stem
            if (_soloStem.value == stem) {
                _soloStem.value = null
            }
        }
        updateVolume()
    }

    private fun updateVolume() {
        val active = _activeStem.value ?: return
        val isMuted = _mutedStems.value.contains(active)
        val solo = _soloStem.value
        val isSilencedBySolo = (solo != null && solo != active)

        if (isMuted || isSilencedBySolo) {
            exoPlayer?.volume = 0.0f
        } else {
            exoPlayer?.volume = 1.0f
        }
    }

    fun togglePlayPause() {
        exoPlayer?.let { player ->
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs)
        _currentPositionMs.value = positionMs
    }

    fun setPitchSemitones(shift: Float) {
        semitones = shift.coerceIn(-12f, 12f)
        updatePlaybackParams()
    }

    fun setTempo(speed: Float) {
        tempo = speed.coerceIn(0.5f, 2.0f)
        updatePlaybackParams()
    }

    private fun updatePlaybackParams() {
        val pitchMultiplier = 2.0.pow((semitones / 12.0).toDouble()).toFloat()
        exoPlayer?.playbackParameters = PlaybackParameters(tempo, pitchMultiplier)
    }

    fun stop() {
        exoPlayer?.stop()
        _isPlaying.value = false
        progressJob?.cancel()
    }

    fun release() {
        stop()
        exoPlayer?.release()
        exoPlayer = null
        scope.cancel()
    }
}
